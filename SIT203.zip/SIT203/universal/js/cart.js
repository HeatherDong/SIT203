//delete the product item
$(".deleteItem").click(function(){
    var rowIndex = $(this).parent().parent().index()+1;
    $(this).parent().parent().remove();
    $.ajax({
        type:'GET',
        url:'basket.php',
        data:{item:rowIndex},
        success:
            function(){
                getTotal();
            }
    });
});
//change the amount of the product
$(".itemCount").bind("input propertychange",function(event){
    var amount = $(this).val();
    if(parseInt(amount)<1){
        $(this).val(1);
        amount = $(this).val();
    }
    var rowIndex = $(this).parent().parent().index()+1;
    var unitPrice = $(this).parent().parent().children(".unitPrice").text();
    var subTotal = parseFloat(unitPrice.substring(1)) * parseInt(amount);
    $(this).parent().parent().children(".subTotal").html("$"+subTotal+".00");
    $.ajax({
        type:'GET',
        url:'basket.php',
        data:{amount:amount,item1:rowIndex},
        success:
            function(){
                getTotal();
            }
    });
});
//turn to the checkout1 page
$('.toCheckout1').click(function(){
    var subTotal = $('#orderSubtotal').text();
    var gst = $('#GST').text();
    var totalFee = $('#totalFee').text();
    if(subTotal=="$0.00"){
        alert("Please add items to the shopping cart");
    }
    else{
    window.location.href = "checkout1.php?subtotal="+subTotal+"&gst="+gst+"&totalFee="+totalFee;
    }
});
//calculate the right fee form
function getTotal(){
    var tds=0;
    var count=0;
    $("tbody tr").each(function(){
        if($(this).find("td").eq(5).text()!=""){
            var itemPrice = $(this).find("td").eq(5).text().substring(1);
            tds = tds+ parseFloat(itemPrice);
            count = count+1;
        }
    });
    $('#totalPrice').html("$"+tds+".00");
    $('#orderSubtotal').html($('#totalPrice').text());
    var gst = parseFloat($('#totalPrice').text().substring(1))*0.1;
    gst = gst.toFixed(2);
    if(gst==null){
        $('#GST').html("$ 0.00");
    }
    else{
        $('#GST').html("$"+gst);
    }
    $("#totalFee").html("$"+ (parseFloat($('#totalPrice').text().substring(1))*1.1+20).toFixed(2));

    if(count < 1){
        $('.fa-shopping-cart').next().html(count+" item in cart");
        $("#shippingFee").html("$0.00");
        $("#totalFee").html("$0.00");
    }
    else if(count ==1){
        $('.fa-shopping-cart').next().html(count+" item in cart");
        $("#totalFee").html("$"+ (parseFloat($('#totalPrice').text().substring(1))*1.1+20).toFixed(2));
    }
    else{
        $('.fa-shopping-cart').next().html(count+"  items in cart");
        $("#totalFee").html("$"+ (parseFloat($('#totalPrice').text().substring(1))*1.1+20).toFixed(2));
    }
    $('.itemText').html("You currently have "+ count +" item in your cart.");

}

$('#orderSubtotal').html($('#totalPrice').text());
var gst = parseFloat($('#totalPrice').text().substring(1))*0.1;
gst = gst.toFixed(2);
if(gst==null){
    $('#GST').html("$ 0.00");
}
else{
    $('#GST').html("$"+gst);
}
var Count=0;
$("tbody tr").each(function(){
    if($(this).find("td").eq(5).text()!=""){
        Count = Count+1;
    }
});
if(Count<1){
    $("#shippingFee").html("$0.00");
    $("#totalFee").html("$0.00");
}
else{
    $("#totalFee").html("$"+ (parseFloat($('#totalPrice').text().substring(1))*1.1+20).toFixed(2));
}
