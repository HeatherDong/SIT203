/*function checkCaptcha(){
    alert($('#captcha').val());
    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            document.getElementById('captchaMessage').innerHTML=xmlhttp.responseText;
            alert("success");
            alert(xmlhttp.responseText);
        }
    };
    xmlhttp.open("GET","php/checkCaptcha.php?captcha="+$('#captcha').val,true);
    xmlhttp.send();
}*/
/*

var temp= window.location.search;
if(temp.indexOf("false") > 0 ){
    document.getElementById('captchaMessage').innerHTML = "The captcha is incorrect.";
}*/
