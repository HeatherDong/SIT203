/**
 AUTHOR HAIQI DONG
 STUDENT ID 217196731
 **/

//global variables
var xmlhttp;
var productList;
var html = "";
var furniture = function(pic1,pic2,productName,brand,price){
    this.pic1 = pic1;
    this.pic2 = pic2;
    this.productName = productName;
    this.brand = brand;
    this.price = price;
}
//the parameter used by price range filter
var priceNum = {};
//the parameters from index page
var count=0;
//creating the xml object
//HAIQI DONG referenced from: http://www.w3school.com.cn/ajax/ajax_xmlhttprequest_create.asp, July 2018.
function createXmlObj(url) {

    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
    else if (window.ActiveXObject){
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    else{
        alert("Your browser does not support ajax!");
    }
    if (xmlhttp!=null) {
        xmlhttp.onreadystatechange = onResponse;
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
    else{
        alert("Errors!");
    }

}
//callBack function begin
function onResponse(){
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        var furnitureArray = new Array;
        var productList_furn = xmlhttp.responseXML.documentElement.getElementsByTagName('FURNITURE');
        var x = productList_furn.length;
        var productList_acc = xmlhttp.responseXML.documentElement.getElementsByTagName('ACCESSORY');
        var y = productList_acc.length;

        showParameter();

        if($(".main-menu").hasClass("classification")){
            var Classification = $(".classification").text();
            productList = xmlhttp.responseXML.documentElement.getElementsByTagName('ACCESSORY');
            $("#furn_tag").removeClass("active");
            $("#acce_tag").addClass("active");
            $('#currShow').empty().append();
            $("#currShow").append($(".product").length);
            document.getElementById("title").innerHTML = "Accessories";
            document.getElementById("article-title").innerHTML ="Accessories";
            document.getElementById("intro").innerHTML = "In our Accessories department we offer wide selection of the best accessories we have found and carefully selected worldwide.";

        }
        else
            {
            productList = xmlhttp.responseXML.documentElement.getElementsByTagName('FURNITURE');
            }


         if($(".menu-text").hasClass("furnitureFilter")){
             $(this).parent().addClass("active");
             var type = $(".furnitureFilter").children().text();
             if(type == 'Chairs'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('CHAIR');
                 addFurniture();
             }
             else if(type == 'Tables'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('TABLE');
                 addFurniture();
             }
             else if(type == 'Beds'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('BED');
                 addFurniture();
             }
             else if(type == 'Storage'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('STORAGE');
                 addFurniture();
             }
             else if(type == 'Home Deco'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('HOMEDECO');
                 addAccessories();
             }
             else if(type == 'Textiles & Rugs'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('TEXTILERUG');
                 addAccessories();
             }
             else if(type == 'Lighting'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('LIGHTING');
                 addAccessories();
             }
             else if(type == 'Plant pots & Stands'){
                 productList = xmlhttp.responseXML.documentElement.getElementsByTagName('PLANTPOTSTAND');
                 addAccessories();
             }

        }
        for (var i = 0; i <productList.length; i++) {
                var productName = $(productList[i]).find("PRODUCT").text();
                var productImg1 = $(productList[i]).find("IMAGE1").text();
                var productImg2 = $(productList[i]).find("IMAGE2").text();
                var productBrand = $(productList[i]).find("BRAND").text();
                var productPrice = parseInt($(productList[i]).find("PRICE").text());
                furnitureArray[i] = new furniture(productImg1, productImg2, productName, productBrand, productPrice);
        }

        var brandValues =[];
        var totalCount = furnitureArray.length;
        var pageSize = setSize();
        var pageCounts = Math.ceil(totalCount / pageSize);
        var currentPage = 1;
        var minPrice;
        var maxPrice;
        $('#products').empty();
        $('#pages').empty();
        $("#totalShow").empty().append();
        $("#totalShow").append(totalCount);
        $("#totalFurniture").empty().append();
        $("#totalFurniture").append(x);
        $("#totalAcce").empty().append();
        $("#totalAcce").append(y);
        $('#currShow').empty().append();
        $("#currShow").append($(".product").length);

        //acquire the brands amount
        var brandAmount=[];
        furnitureArray.forEach(function(v){
            brandAmount.push(v.brand);
        });
        countBrands(brandAmount);

        //sorting the products by price or brands
        if($("#decrease").hasClass("selecting")) {
            if($("#sortByRange").hasClass("settingRange") && $("#brandFilter").hasClass("applyFilter")){
                filteringByBrand();
                filteringByPrice();
            }
            else if($("#sortByRange").hasClass("settingRange")) {
                filteringByPrice();
            }
            else if($("#brandFilter").hasClass("applyFilter")){
                filteringByBrand();
            }
            decreaseByPrice();
            loadDefaultProduct();
        }
        else if($("#increase").hasClass("selecting")){
            if($("#sortByRange").hasClass("settingRange") && $("#brandFilter").hasClass("applyFilter")){
                filteringByBrand();
                filteringByPrice();
            }
            else if($("#sortByRange").hasClass("settingRange")){
                filteringByPrice();
            }
            else if($("#brandFilter").hasClass("applyFilter")){
                filteringByBrand();
            }
            increaseByPrice();
            loadDefaultProduct();
        }
        else if($("#brandFilter").hasClass("applyFilter")){
            if($("#sortByRange").hasClass("settingRange")){
                filteringByBrand();
                filteringByPrice();
            }
            else{
                filteringByBrand();
            }
            loadDefaultProduct();
        }
        else if($("#sortByRange").hasClass("settingRange")){
            if($("#brandFilter").hasClass("applyFilter")){
                filteringByBrand();
                filteringByPrice();
            }
            else{
                filteringByPrice();
            }
            loadDefaultProduct();
        }
        else {
            loadDefaultProduct();
        }
        loadPageNumber();
        addToCart();

        //load the page number
        function loadPageNumber(){
            //the left arrows
            var leftArrow = '<li class="pageNum" left="1"><a href="#">' + '&laquo;' + '</a>' + '</li>';
            $('#pages').append(leftArrow);
            //page numbers
            for (var i = 1; i <= pageCounts; i++) {
                if (i == 1) {
                    var pageButton = '<li class="pageNum active"><a href="#" selectPage="' + i + '" left="">' + i + '</a>' + '</li>';
                }
                else {
                    var pageButton = '<li class="pageNum"><a href="#" selectPage="' + i + '" left="">' + i + '</a>' + '</li>';
                }
                $('#pages').append(pageButton);
            }
            //the right arrows
            var rightArrow = '<li class="pageNum" right="1"><a href="#">' + '&raquo;' + '</a>' + '</li>';
            $('#pages').append(rightArrow);

        }
        //load default products
        function loadDefaultProduct(){
            $("#products").empty().append();
            if(typeof furnitureArray !== 'undefined') {
                for (i = (currentPage - 1) * pageSize; i < pageSize * currentPage; i++) {
                    var html = " <div class='col-md-4 col-sm-6'> " + "<div class='product'> " + "<div class='flip-container'>" + "<div class='flipper'>" + "<div class='front'>" + "<a href=# class='pictureDetail'> " + "<img src='" + furnitureArray[i].pic1 + "' alt='"+ furnitureArray[i].productName +"' class='img-responsive'></a></div>" + "<div class='back'><a href=# class='pictureDetail'>" + "<img src='" + furnitureArray[i].pic2 + "' alt='\"+ furnitureArray[i].productName +\"' class='img-responsive'></a></div>" + "</div></div><a href=# class='invisible'>" + " <img src='img/product1.jpg' alt='' class='img-responsive'></a>" + "<div class='text'><h3><a href='#' class='showDetail'>" + furnitureArray[i].productName + "</a></h3>" + "<p class='price'>" + "$" + furnitureArray[i].price + "</p><p class='buttons'>" + "<a href=# class='btn btn-default showDetails'>View detail</a>" + "<a class='btn btn-primary addCart'>" + "<i class='fa fa-shopping-cart'></i>Add to cart</a></p>" + "</div></div></div>";
                    $("#products").append(html);
                    $('#currShow').empty().append();
                    $("#currShow").append($(".product").length);
                }
            }
            showDetails();
        }
        //change the page by clicking the page number
        $(".pageNum a").click(function () {
            //if clicking the page numbers
            if ($(this).attr('selectPage') != null) {
                var selectPage = $(this).attr('selectPage');
                $('#products').empty().append();
                $(this.parentNode).addClass("active").siblings().removeClass("active");
                for (i = (selectPage - 1) * pageSize; i < pageSize * selectPage; i++) {
                    if(typeof furnitureArray[i] !== 'undefined') {
                        var html = " <div class='col-md-4 col-sm-6'> " + "<div class='product'> " + "<div class='flip-container'>" + "<div class='flipper'>" + "<div class='front'>" + "<a href=# class='pictureDetail'> " + "<img src='" + furnitureArray[i].pic1 + "' alt='\"+ furnitureArray[i].productName +\"' class='img-responsive'></a></div>" + "<div class='back'><a href=# class='pictureDetail'>" + "<img src='" + furnitureArray[i].pic2 + "' alt='\"+ furnitureArray[i].productName +\"' class='img-responsive'></a></div>" + "</div></div><a href=# class='invisible'>" + " <img src='img/product1.jpg' alt='' class='img-responsive'></a>" + "<div class='text'><h3><a href='#' class='showDetail'>" + furnitureArray[i].productName + "</a></h3>" + "<p class='price'>" + "$" + furnitureArray[i].price + "</p><p class='buttons'>" + "<a href=# class='btn btn-default showDetails'>View detail</a>" + "<a class='btn btn-primary addCart'>" + "<i class='fa fa-shopping-cart'></i>Add to cart</a></p>" + "</div></div></div>";
                        $("#products").append(html);
                        $('#currShow').empty().append();
                        $("#currShow").append($(".product").length);
                    }
                }

            }
            //if clicking the left arrow
            else if ($(this).parent().attr('left') == 1) {
                currentPage = $(".pageNum.active").find("a").text();
                goPrePage(currentPage);
            }
            //if clicking the right arrow
            else if ($(this).parent().attr('right') == 1) {
                currentPage = $(".pageNum.active").find("a").text();
                goNextPage(currentPage);
            }
            showDetails();
            addToCart();
        })
        //go to the previous page
        function goPrePage(currentPage) {
            var leftPage = (currentPage - 1);
            var pre = $(".pageNum.active").prev();
            if ($(pre).attr('left') != '1') {
                $('#products').empty().append();
                pre.addClass("active").siblings().removeClass("active");
                for (i = (leftPage - 1) * pageSize; i < pageSize * leftPage; i++) {
                    if(typeof furnitureArray[i] !== 'undefined') {
                        var html = " <div class='col-md-4 col-sm-6'> " + "<div class='product'> " + "<div class='flip-container'>" + "<div class='flipper'>" + "<div class='front'>" + "<a href=# class='pictureDetail'> " + "<img src='" + furnitureArray[i].pic1 + "' alt='\"+ furnitureArray[i].productName +\"' class='img-responsive'></a></div>" + "<div class='back'><a href=# class='pictureDetail'>" + "<img src='" + furnitureArray[i].pic2 + "' alt='\"+ furnitureArray[i].productName +\"' class='img-responsive'></a></div>" + "</div></div><a href=# class='invisible'>" + " <img src='img/product1.jpg' alt='' class='img-responsive'></a>" + "<div class='text'><h3><a href='#' class='showDetail'>" + furnitureArray[i].productName + "</a></h3>" + "<p class='price'>" + "$" + furnitureArray[i].price + "</p><p class='buttons'>" + "<a href=# class='btn btn-default showDetails'>View detail</a>" + "<a class='btn btn-primary addCart'>" + "<i class='fa fa-shopping-cart'></i>Add to cart</a></p>" + "</div></div></div>";
                        $("#products").append(html);
                        $('#currShow').empty().append();
                        $("#currShow").append($(".product").length);
                    }
                }
            }
            showDetails();
            addToCart();
        }
        //go to the next page
        function goNextPage(currentIndex) {
            var rightPage = (parseInt(currentIndex) + 1);
            var next = $(".pageNum.active").next();
            if ($(next).attr('right') != '1') {
                $('#products').empty().append();
                next.addClass("active").siblings().removeClass("active");
                    for (i = (rightPage - 1) * pageSize; i < pageSize * rightPage; i++) {
                        if(typeof furnitureArray[i] !== 'undefined') {
                            var html = " <div class='col-md-4 col-sm-6'> " + "<div class='product'> " + "<div class='flip-container'>" + "<div class='flipper'>" + "<div class='front'>" + "<a href=# class='pictureDetail'> " + "<img src='" + furnitureArray[i].pic1 + "' alt='\"+ furnitureArray[i].productName +\"' class='img-responsive'></a></div>" + "<div class='back'><a href=# class='pictureDetail'>" + "<img src='" + furnitureArray[i].pic2 + "' alt='\"+ furnitureArray[i].productName +\"' class='img-responsive'></a></div>" + "</div></div><a href=# class='invisible'>" + " <img src='img/product1.jpg' alt='' class='img-responsive'></a>" + "<div class='text'><h3><a href='#' class='showDetail'>" + furnitureArray[i].productName + "</a></h3>" + "<p class='price'>" + "$" + furnitureArray[i].price + "</p><p class='buttons'>" + "<a href=# class='btn btn-default showDetails'>View detail</a>" + "<a class='btn btn-primary addCart'>" + "<i class='fa fa-shopping-cart'></i>Add to cart</a></p>" + "</div></div></div>";
                            $("#products").append(html);
                            $('#currShow').empty().append();
                            $("#currShow").append($(".product").length);
                        }
                    }
            }
            showDetails();
            addToCart();
        }
        //set the page size
        function setSize() {
            if($("#allProduct").hasClass("setSuccess")){
                pageSize = totalCount;
            }
            else if($("#small").hasClass("setSuccess")){
                if(totalCount<6)
                pageSize = totalCount;
                else pageSize = 6;
            }
            else if($("#big").hasClass("setSuccess")){
                if(totalCount<12)
                    pageSize = totalCount;
                else pageSize = 12;
            }
            else{
                if(totalCount<6)
                    pageSize = totalCount;
                else pageSize = 6;
            }
            return pageSize;
        }
        //remove the empty value in the array
        function deleteSpace(array){
            for(var a = 0 ;a<array.length; a++)
            {
                if(typeof(array[a]) == "undefined"|| array[a] == "")
                {
                    array.splice(a,1);
                    a= a-1;
                }
            }
            return array;
        }
        //counting the amount of each brand
        function countBrands(array) {
            var tempArray = [];
            array.sort();
            document.getElementById("Artdeco").innerHTML = '('+ 0 +')';
            document.getElementById("Fantastic").innerHTML = '('+ 0 + ')';
            document.getElementById("The_factory").innerHTML = '('+ 0 + ')';
            document.getElementById("Universal").innerHTML = '('+ 0 + ')';
            document.getElementById("Ikea").innerHTML = '('+ 0 + ')';
            for(var i=0;i<array.length;){
                var brandCount = 0;
                for(var j=i; j<array.length;j++){
                    if(array[i]==array[j]){
                        brandCount++;
                    }
                }
                tempArray.push({
                     brandBranch:array[i],
                     totalAmount:brandCount,
                })
                i += brandCount;
            }
            for(var a=0;a<tempArray.length;a++){
                switch (tempArray[a].brandBranch)
                {
                    case "Artdeco":
                        document.getElementById("Artdeco").innerHTML = '('+tempArray[a].totalAmount+')';
                        break;
                    case "Fantastic":
                        document.getElementById("Fantastic").innerHTML = '('+tempArray[a].totalAmount + ')';
                        break;
                    case "The factory":
                        document.getElementById("The_factory").innerHTML = '('+tempArray[a].totalAmount + ')';
                        break;
                    case "Universal":
                        document.getElementById("Universal").innerHTML = '('+tempArray[a].totalAmount + ')';
                        break;
                    case "Ikea":
                        document.getElementById("Ikea").innerHTML = '('+tempArray[a].totalAmount + ')';
                        break;
                }
            }

        }
        //sorting by high-to-low
        function decreaseByPrice() {
            furnitureArray.sort(function(hObject,lObject){
                return lObject.price - hObject.price
            });
        }
        //sorting by low-to-high
        function increaseByPrice() {
            furnitureArray.sort(function(hObject,lObject){
                return hObject.price - lObject.price
            });
        }
        //brands filter
        function filteringByBrand(){
            $('input[class="brandName"]:checked').each(function () {
                brandValues.push($(this).attr("name"));
            });
            var tempArray = new Array;
            var targetBrands = [];
            for(var i = 0;i< furnitureArray.length; i++){
                tempArray[i] = new furniture(furnitureArray[i].pic1, furnitureArray[i].pic2, furnitureArray[i].productName,furnitureArray[i].brand,furnitureArray[i].price);
            }
            furnitureArray.length = 0;
            for (var j = 0; j < brandValues.length; j++) {
                targetBrands[j] = brandValues[j];
                for (var i = 0; i< tempArray.length; i++) {
                    if(targetBrands[j] == tempArray[i].brand){
                        furnitureArray[i] = new furniture(tempArray[i].pic1, tempArray[i].pic2, tempArray[i].productName,tempArray[i].brand,tempArray[i].price);
                    }
                }
            }
            deleteSpace(furnitureArray);
            totalCount = furnitureArray.length;
            pageSize = setSize();
            pageCounts = (Math.ceil(totalCount / pageSize));
            $("#totalShow").empty().append();
            $("#totalShow").append(totalCount);
            $('#currShow').empty().append();
            $("#currShow").append($(".product").length);
            $('#pages').empty();
        }
        //price range filter
        function filteringByPrice(){
            priceNum = priceFilter($(".range-price").text());
            minPrice = parseInt(priceNum[0]);
            maxPrice = parseInt(priceNum[1]);
            var tempArray = new Array;
            for(var i = 0;i< furnitureArray.length; i++){
                tempArray[i] = new furniture(furnitureArray[i].pic1, furnitureArray[i].pic2, furnitureArray[i].productName,furnitureArray[i].brand,furnitureArray[i].price);
            }
            furnitureArray.length = 0;
            for (var i = 0; i < tempArray.length; i++) {
                if(minPrice <= parseInt(tempArray[i].price) && parseInt(tempArray[i].price)<=maxPrice){
                    furnitureArray[i] = new furniture(tempArray[i].pic1, tempArray[i].pic2, tempArray[i].productName,tempArray[i].brand,tempArray[i].price);
                }
            }
            deleteSpace(furnitureArray);
            totalCount = furnitureArray.length;
            pageSize = setSize();
            pageCounts = (Math.ceil(totalCount / pageSize));
            $("#totalShow").empty().append();
            $("#totalShow").append(totalCount);
            $('#currShow').empty().append();
            $("#currShow").append($(".product").length);
            $('#pages').empty();
        }
        //changing the text info (title and introduction)
        function addFurniture(){
            $("#acce_tag").removeClass("active");
            $("#furn_tag").addClass("active");
            $('#currShow').empty().append();
            $("#currShow").append($(".product").length);
            document.getElementById("title").innerHTML = "Furniture";
            document.getElementById("article-title").innerHTML ="Furniture";
            document.getElementById("intro").innerHTML = "In our Furniture department we offer wide selection of the best furniture we have found and carefully selected worldwide.";

        }
        //changing the text info (title and introduction)
        function addAccessories(){
            $(".menu-accessories").removeClass("filtering");
            $("#furn_tag").removeClass("active");
            $("#acce_tag").addClass("active");
            $('#currShow').empty().append();
            $("#currShow").append($(".product").length);
            document.getElementById("title").innerHTML = "Accessories";
            document.getElementById("article-title").innerHTML ="Accessories";
            document.getElementById("intro").innerHTML = "In our Accessories department we offer wide selection of the best accessories we have found and carefully selected worldwide.";
        }
        //judge the parameters from index.php
        function showParameter(){
            var paramType = getParameter("type");
            if(count==0) {
                if (paramType == 'Chairs') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('CHAIR');
                    $(".chairs").parent().addClass("active").siblings().removeClass("active");
                    $(".chairs").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addFurniture();
                }
                else if (paramType == 'Tables') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('TABLE');
                    $(".tables").parent().addClass("active").siblings().removeClass("active");
                    $(".tables").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addFurniture();
                }
                else if (paramType == 'Beds') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('BED');
                    $(".beds").parent().addClass("active").siblings().removeClass("active");
                    $(".beds").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addFurniture();
                }
                else if (paramType == 'Storage') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('STORAGE');
                    $(".storages").parent().addClass("active").siblings().removeClass("active");
                    $(".storages").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addFurniture();
                }
                else if (paramType == 'HomeDeco') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('HOMEDECO');
                    $(".homeDecoes").parent().addClass("active").siblings().removeClass("active");
                    $(".homeDecoes").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addAccessories();
                }
                else if (paramType == 'TextilesRugs') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('TEXTILERUG');
                    $(".textiles").parent().addClass("active").siblings().removeClass("active");
                    $(".textiles").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addAccessories();
                }
                else if (paramType == 'Lighting') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('LIGHTING');
                    $(".lightings").parent().addClass("active").siblings().removeClass("active");
                    $(".lightings").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addAccessories();
                }
                else if (paramType == 'PlantpotsStands') {
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('PLANTPOTSTAND');
                    $(".plantPots").parent().addClass("active").siblings().removeClass("active");
                    $(".plantPots").parent().addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
                    addAccessories();
                }
                else if(paramType == 'accessories'){
                    productList = xmlhttp.responseXML.documentElement.getElementsByTagName('ACCESSORY');
                    $(".chairs").parent().siblings().removeClass("active");
                    $(".main-menu").addClass("classification");
                    addAccessories();
                }
                count=1;
            }
            paramType = null;
        }
        //passing to the shopping cart;
        $(".addCart").click(function(){
            var productName = $(this).parent().parent().children("h3").children('a').text();
            var price = $(this).parent().prev().text();
            $.ajax({
                type:'GET',
                url:'basket.php',
                data:{productName:productName,price:price},
                success:
                    function(){
                        window.location.href="basket.php";
                    }
            });
        });
        //pass the parameters to detail.php
        function showDetails(){
            $(".showDetail").click(function(){
                var number = $("#totalFurniture").text();
                var number1 = $("#totalAcce").text();
                var productId = $(this).text();
                var type = $(".category-menu li.active .category-branch").text();
                type = type.replace(/[\d]+/,'');
                window.location.href = "detail.php?id="+productId+"&count="+number+"&count1="+number1+"&type="+type;
            });
            $(".showDetails").click(function(){
                var number = $("#totalFurniture").text();
                var number1 = $("#totalAcce").text();
                var productId = $(this).parent().parent().children("h3").text();
                var type = $(".category-menu li.active .category-branch").text();
                type = type.replace(/[\d]+/,'');
                window.location.href = "detail.php?id="+productId+"&count="+number+"&count1="+number1+"&type="+type;
            });
            $(".pictureDetail").click(function(){
                var productId = $(this).parent().parent().parent().siblings("div").children("h3").text();
                var number = $("#totalFurniture").text();
                var number1 = $("#totalAcce").text();
                var type = $(".category-menu li.active .category-branch").text();
                type = type.replace(/[\d]+/,'');
                window.location.href = "detail.php?id="+productId+"&count="+number+"&count1="+number1+"&type="+type;
            });
        }
    }
}
//callBack function end

//showing 12 products per page
function setBigger() {
    $("#big").addClass("setSuccess").siblings().removeClass("setSuccess");
    $("#big").addClass("btn-primary").siblings().removeClass("btn-primary");
    onResponse();
}
//showing 6 products per page
function setSmaller() {
    $("#small").addClass("setSuccess").siblings().removeClass("setSuccess");
    $("#small").addClass("btn-primary").siblings().removeClass("btn-primary");
    onResponse();
}
//showing all products per page
function setAll() {
    $("#allProduct").addClass("setSuccess").siblings().removeClass("setSuccess");
    $("#allProduct").addClass("btn-primary").siblings().removeClass("btn-primary");
    onResponse();
}
//activate sorting by price
function sortByPrice(){
    if($('select option:selected').val() == "Price: high-low"){
        $("#decrease").addClass("selecting").siblings().removeClass("selecting");
    }
    else if($('select option:selected').val() == "Price: low-high"){
        $("#increase").addClass("selecting").siblings().removeClass("selecting");
    }
    else if($('select option:selected').val() == "Default"){
        $("#decrease").removeClass("selecting");
        $("#increase").removeClass("selecting");
    }
    onResponse();
}
//clear the brands filter
function clearMark(){
    $(":checkbox").attr("checked",false);
    $("#brandFilter").removeClass("applyFilter");
    onResponse();
}
//activate the brands filter
function brandFilter(){
    $("#brandFilter").addClass("applyFilter");
    onResponse();
}
//get the price range
//HAIQI DONG referenced from: https://www.cnblogs.com/lxk0301/p/7092720.html July 2018.
var priceFilter = function (String,isFilter) {
        isFilter = isFilter || false;
        if (typeof String === "string") {
            var arr = String.match( isFilter ? /[1-9]\d{1,}/g : /\d{2,}/g);
            return arr.map(function (item) {
                return item;
            });
        } else {
            return [];
        }
}
//activate the price range filter
function setPriceRange(){
    $("#sortByRange").addClass("settingRange");
    onResponse();
}
//clear the price range filter
function clearMark2(){
    $("#sortByRange").removeClass("settingRange");
    onResponse();
}
//get the passing parameters from the other pages
//HAIQI DONG referenced from: https://blog.csdn.net/baidu_25943379/article/details/50997282 July 2018.
function getParameter(param)
{
    var query = window.location.search;
    var iLen = param.length;
    var iStart = query.indexOf(param);
    if (iStart == -1)
        return "";
    iStart += iLen + 1;
    var iEnd = query.indexOf("&", iStart);
    if (iEnd == -1)
        return query.substring(iStart);
    return query.substring(iStart, iEnd);
}
//changing the selected status when selecting the menu
$(".menu-text a").click(function(){
    $(this).parent().addClass("active").siblings().removeClass("active");
    $(this).parent().parent().parent().siblings().children("ul").children("li").removeClass("active");
    $(".furnitureFilter").removeClass("furnitureFilter");
    $(this.parentNode).addClass("furnitureFilter").siblings().removeClass("furnitureFilter");
    onResponse();
})
//changing the selected status when selecting the menu
$(".main-menu").click(function(){
    $(this).siblings().children("li").removeClass("active");
    $(this).parent().siblings().children("ul").children("li").removeClass("active");
    $(".furnitureFilter").removeClass("furnitureFilter");
    $(this).addClass("classification");
    onResponse();
});

function addToCart(){
    $(".addCart").click(function(){
        var productName = $(this).parent().parent().children("h3").children('a').text();
        var price = $(this).parent().prev().text();
        $.ajax({
            type:'GET',
            url:'basket.php',
            data:{productName:productName,price:price},
            success:
                function(){
                    window.location.href="basket.php";
                }
        });
    });
}
