//passing password info to the php
$('#savePassword').click(function(){
    var oldPassword = $("#password_old").val();
    var newPassword1 = $("#password_1").val();
    var newPassword2 = $("#password_2").val();
    if ($("#password_old").val() == "") {
        $("#password_oldError").html("The old password is necessary.");
    }else{
        $("#password_oldError").html("");
    }
    if ($("#password_1").val() == "") {
        $("#password_1Error").html("The new password is necessary.");
    }
    if ($("#password_2").val() == "") {
        $("#password_2Error").html("The repeat password is necessary.");
    }
    if($("#password_2").val()!= $("#password_1").val()){
        $("#password_2Error").html("The repeat password should be same as the new password.");
    }
    if($("#password_oldError").text()=="" && $("#password_1Error").text() == ""&& $("#password_2Error").text() == ""){
        window.location.href = "php/changePassword.php?oldPassword="+oldPassword+"&newPassword1="+newPassword1+"&newPassword2"+newPassword2;
    }
});
