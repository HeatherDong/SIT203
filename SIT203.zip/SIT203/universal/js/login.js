//pass the login info to php
$(".login").click(function(){
    var loginName = $("#email-modal").val();
    var loginPwd = $("#password-modal").val();
    window.location.href = "php/login.php?loginName="+loginName+"&loginPwd="+loginPwd;
});



