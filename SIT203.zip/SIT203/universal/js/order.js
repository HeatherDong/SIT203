//pass product info to the basket.php
$(".addCart").click(function(){
    var productName = $(".box").children("h1").text();
    var image = $("#mainImage").children("img").attr('src');
    var price = $(".box").children("p.price").text();
    var id = $(".ID").text();
    $.ajax({
        type:'GET',
        url:'basket.php',
        data:{productName:productName,id:id,price:price,image:image},
        success:
            function(){
                window.location.href="basket.php";
            }
    });
});