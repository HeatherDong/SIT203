//pass product info to the basket.php
$(".addCart").click(function(){
    var productName = $(this).parent().parent().children("h3").children('a').text();
    var price = $(this).parent().prev().text();
    $.ajax({
        type:'GET',
        url:'basket.php',
        data:{productName:productName,price:price},
        success:
            function(){
                window.location.href="basket.php";

            }});
});
//when clicking "show detail" button, passing parameters to the detail page.
$(".showDetail").click(function(){
    var productId = $(this).text();
    passingSuggesstion(productId);
    });
//when clicking product name, passing parameters to the detail page.
$(".showDetails").click(function(){
    var productId = $(this).parent().parent().children("h3").text();
    passingSuggesstion(productId);
});
//when clicking picture, passing parameters to the detail page.
$(".pictureDetail").click(function(){
    var productId = $(this).parent().parent().parent().siblings("div").children("h3").text();
    passingSuggesstion(productId);
});
//passing product parameters to detail page.
function passingSuggesstion(productId){
    var count=0;
    var count1=0;
    $.ajax({
        url: 'furniture_all.xml',
        type: 'GET',
        dataType: 'xml',
        success: function(xml) {
            $(xml).find("FURNITURE").each(function(){
                count=count+1;
            });
            $(xml).find("ACCESSORY").each(function(){
                count1=count1+1;
            });
            $(xml).find("PRODUCT").each(function () {
                var name = $(this).text();
                if(name==productId){
                    var activeClass;
                    var type=this.parentNode.nodeName;
                    var number = count;
                    var number1 = count1;
                    if(type=='BED'||type=='CHAIR'||type=='STORAGE'||type=='TABLE'){
                        type="Furniture"
                    }
                    else{
                        type="Accessory"
                    }
                    window.location.href = "detail.php?id="+productId+"&count="+number+"&count1="+number1+"&type="+type;
                }
            })
        }
    });
}

