/*Referenced from : https://blog.csdn.net/zshdd/article/details/72961391*/
//Implement the country, state, city selections in checkout1 page
var loadXML = function (xmlFile) {
    var xmlDoc;
    // code for IE6, IE5
    if (window.ActiveXObject) {
        xmlDoc = new ActiveXObject('Microsoft.XMLDOM');
        xmlDoc.async = false;
        xmlDoc.load(xmlFile);
    }
    // code for IE7+, Firefox, Chrome, Opera, Safari
    else
    {
        var xmlhttp = new window.XMLHttpRequest();
        xmlhttp.open("GET", xmlFile, false);
        xmlhttp.send(null);
        if (xmlhttp.readyState == 4) {
            xmlDoc = xmlhttp.responseXML.documentElement;
        }
    }
    return xmlDoc;
};
//options initialization
var countryOption = document.getElementById('country');
var stateOption = document.getElementById("state");
var cityOption = document.getElementById("city");
countryOption.options.add(new Option("--Please select--",""));
stateOption.options.add(new Option("--Please select--",""));
cityOption.options.add(new Option("--Please select--",""));

//country list initialization
var xmlDoc = loadXML("LocList.xml");
var countryList=xmlDoc.getElementsByTagName("CountryRegion");
for(var i=0;i<countryList.length;i++){
    var countryName = countryList[i].getAttribute("Name");
    var countryCode = countryList[i].getAttribute("Code");
    countryOption.add(new Option(countryName,countryCode));
}
//change the style of the input forms
var stateInput = document.getElementById("stateText");
var cityInput = document.getElementById("cityText");

stateInput.onfocus = function(){
    stateInput.style.backgroundColor = "#FFFFFF";
    stateInput.style.color = "#555";
    stateInput.style.border = "1px solid #ccc";
};
cityInput.onfocus = function(){
    cityInput.style.backgroundColor = "#FFFFFF";
    cityInput.style.color = "#555";
    cityInput.style.border = "1px solid #ccc";
};
//select country
countryOption.onchange = function(){
    $("#countryError").empty();
    $("#stateTextError").empty();
    if(this.value!=""){
        stateOption.length = 0;
        stateInput.style.backgroundColor = "#FFFFFF";
        stateInput.style.color = "#555";
        stateInput.style.border = "1px solid #ccc";
        document.getElementById('stateText').value = "";
        stateOption.options.add(new Option("--Please input--",""));
        cityOption.length = 0;
        cityInput.style.backgroundColor = "#FFFFFF";
        cityInput.style.color = "#555";
        cityInput.style.border = "1px solid #ccc";
        document.getElementById('cityText').value = "";
        cityOption.options.add(new Option("--Please input--",""));

        for(var i=0;i<countryList.length;i++){
            var countryCode = countryList[i].getAttribute("Code");

            if(this.value == countryCode){
                var stateList = countryList[i].getElementsByTagName("State");
                var stateNodeName = stateList[0].getAttribute("Name");

                if(stateNodeName == null)
                {
                    var cityList = stateList[0].getElementsByTagName("City");
                    cityOption.length=0;
                    cityInput.style.backgroundColor = "#FFFFFF";
                    cityInput.style.color = "#555";
                    cityInput.style.border = "1px solid #ccc";
                    document.getElementById('cityText').value = "";
                    cityOption.options.add(new Option("--Please select--",""));

                    for(var l=0;l<cityList.length;l++)
                    {
                        var cityName=cityList[l].getAttribute("Name");
                        var cityCode=cityList[l].getAttribute("Code");
                        cityOption.add(new Option(cityName,cityCode));
                    }
                }
                else
                {
                    stateOption.length = 0;
                    stateInput.style.backgroundColor = "#FFFFFF";
                    stateInput.style.color = "#555";
                    stateInput.style.border = "1px solid #ccc";
                    document.getElementById('stateText').value = "";
                    stateOption.options.add(new Option("--Please select--",""));
                    for(var j=0;j<stateList.length;j++){
                        var stateName = stateList[j].getAttribute("Name");
                        var stateCode = stateList[j].getAttribute("Code");
                        stateOption.add(new Option(stateName,stateCode));
                    }
                }
                break;
            }

        }
    }
    // validate the country is not empty.
    else{
        $("#countryError").html("The country is necessary.");
    }

};
//select the state
stateOption.onchange=function(){
    $("#stateTextError").empty();
    $("#cityTextError").empty();
    stateInput.style.backgroundColor = "#FFFFFF";
    stateInput.style.color = "#555";
    stateInput.style.border = "1px solid #ccc";
    //document.getElementById('stateText').value=this.options[this.selectedIndex].innerHTML;
    document.getElementById('stateText').value=this.options[this.selectedIndex].innerHTML.replace(/\&nbsp;/g, ' ');

    cityOption.length = 0;
    cityInput.style.backgroundColor = "#FFFFFF";
    cityInput.style.color = "#555";
    cityInput.style.border = "1px solid #ccc";
    document.getElementById('cityText').value = "";
    cityOption.options.add(new Option("--Please select--",""));

    if(this.value!=""){
        for(var i=0;i<countryList.length;i++){
            var countryCode = countryList[i].getAttribute("Code");
            if(countryOption.value==countryCode){
                var stateList = countryList[i].getElementsByTagName("State");
                for(var j=0;j<stateList.length;j++){
                    if(stateOption.value==stateList[j].getAttribute("Code")) {
                        var cityList = stateList[j].getElementsByTagName("City");
                        for(var k=0;k<cityList.length;k++)
                        {
                            var cityName = cityList[k].getAttribute("Name");
                            var cityCode = cityList[k].getAttribute("Code");
                            cityOption.add(new Option(cityName,cityCode));
                        }
                    }
                }
                break;
            }
        }
    }
    else{
        $("#stateTextError").html("The state is necessary.");
    }
};
//select the city
cityOption.onchange = function(){
    $("#cityTextError").empty();
    cityInput.style.backgroundColor = "#FFFFFF";
    cityInput.style.color = "#555";
    cityInput.style.border = "1px solid #ccc";
    document.getElementById('cityText').value=this.options[this.selectedIndex].innerHTML.replace(/\&nbsp;/g, ' ');
    if(this.value==""){
        $("#cityTextError").html("The city is necessary.");
    }
};


