//pass login info to php
$("#login").click(function(){
    var loginName = $("#Email").val();
    var loginPwd = $("#Password").val();
    window.location.href = "php/login.php?loginName="+loginName+"&loginPwd="+loginPwd;
});
//validate the form info when clicking the submit button
$("#register").click(function(){
    var userName = $("#name").val();
    var email = $("#email").val();
    var passWord = $("#password_1").val();

    if ($("#name").val() == "") {
        $("#nameError").html("The username name is necessary.");
    }
    else{
        var name = /^[A-Za-z]{6}$/;
        if(!name.test($("#name").val())){
            $("#nameError").html("Username should be 6 digits and only has letter.");
        }
        else{
            $("#nameError").html("");
        }
    }
    if ($("#email").val() == "") {
        $("#emailError").html("The email is necessary.");
    }
    else{
        var mail = /([\w\-]+\@[\w\-]+\.[\w\-]+)/;
        if(!mail.test($("#email").val())){
            $("#emailError").html("Please input the valid email address.");
        }
        else{
            $("#emailError").html("");
        }
    }
    if ($("#password_1").val() == "") {
        $("#password_1Error").html("The password is necessary.");
    }
    else{
        var pwd =/(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[A-Za-z0-9]{8}/;
        if(!pwd.test($("#password_1").val())){
            $("#password_1Error").html("Password must be 8 digits including numbers, uppercase and lowercase letters.");
        }
        else if($("#password_1").val().length!==8){
            $("#password_1Error").html("Password must be 8 digits including numbers, uppercase and lowercase letters.");
        }
        else{
            $("#password_1Error").html("");
        }
    }
    if($("#nameError").text()=="" && $("#emailError").text() == "" && $("#password_1Error").text() == ""){
    window.location.href = "php/registerAccount.php?userName="+userName+"&email="+email+"&passWord="+passWord;
    }
});