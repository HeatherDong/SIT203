//Using ajax to pass the parameters to php validator
//Referenced from shang gao: http://www.deakin.edu.au/~shang/ajax/tmp/form.html
function Validate(error,id,obj) {
    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            document.getElementById(error).innerHTML=xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET","php/validators/"+id+".php?"+id+"="+obj.value,true);
    xmlhttp.send();
}
//pass the parameters in checkout1 form to the session
function submitForm() {

    if ($("#firstname").val() == "") {
        $("#firstnameError").html("The first name is necessary.");
    }
    else{
        var firstname =  /^([A-Za-z\s]*)$/;
        if(!firstname.test($.trim($("#firstname").val()))){
            $("#firstnameError").html("Can only have letters and spaces");
        }
        else{
            $("#firstnameError").html("");
        }
    }
    if ($("#lastname").val() == "") {
        $("#lastnameError").html("The Last name is necessary.");
    }
    else{
        var lastname =  /^([A-Za-z\s]*)$/;
        if(!lastname.test($.trim($("#lastname").val()))){
            $("#lastnameError").html("Can only have letters and spaces");
        }
        else{
            $("#lastnameError").html("");
        }
    }
    if ($("#address").val() == "") {
        $("#addressError").html("The address is necessary.");
    }
    else{
        var address = /^((?:\d+ [a-zA-Z ]{1,5})[a-zA-Z ]+)$/;
        if(!address.test($.trim($("#address").val()))){
            $("#addressError").html("Address must have a house number and a street name, like 55 station street.");
        }
        else{
            $("#addressError").html("");
        }
    }
    if ($("#stateText").val() == "") {
        $("#stateTextError").html("The state is necessary.");
    }
    else{
        var state = /^([A-Za-z\s-]*)$/;
        if(!state.test($.trim($("#stateText").val()))){
            $("#stateTextError").html("Can only have letters, spaces and -");
        }
        else{
            $("#stateTextError").html("");
        }
    }
    if ($("#cityText").val() == "") {
        $("#cityTextError").html("The city is necessary.");
    }
    else{
        var city = /^([A-Za-z\s-]*)$/;
        if(!city.test($.trim($("#cityText").val()))){
            $("#cityTextError").html("Can only have letters, spaces and -");
        }
        else{
            $("#cityTextError").html("");
        }
    }
    if ($("#postcode").val() == "") {
        $("#postcodeError").html("The postcode is necessary.");
    }
    else{
        var postcode = /^(\d{4})$/;
        if(!postcode.test($.trim($("#postcode").val()))){
            $("#postcodeError").html("Postcode can only have 4 digits numbers.");
        }
        else{
            $("#postcodeError").html("");
        }
    }
    if ($("#phone").val() == "") {
        $("#phoneError").html("The telephone is necessary.");
    }
    else{
        var phone = /^(\({0,1}((0|\+61)(2|4|3|7|8)){0,1}\){0,1}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{1}(\ |-){0,1}[0-9]{3})$/;
        if(!phone.test($.trim($("#phone").val()))){
            $("#phoneError").html("Please input the correct phone number.");
        }
        else{
            $("#phoneError").html("");
        }
    }
    if ($("#email").val() == "") {
        $("#emailError").html("The email address is necessary.");
    }
    else{
        var email = /([\w\-]+\@[\w\-]+\.[\w\-]+)/;
        if(!email.test($.trim($("#email").val()))){
            $("#emailError").html("Please input the valid email address");
        }
        else{
            $("#emailError").html("");
        }
    }
    if ($("#country").val() == "") {
        $("#countryError").html("The country is necessary.");
    }

    var errorArray = new Array($("#firstnameError").text(), $("#lastnameError").text(), $("#addressError").text(), $("#stateTextError").text(), $("#cityTextError").text(), $("#postcodeError").text(), $("#phoneError").text(), $("#countryError").text(), $("#emailError").text());
    for (var i = 0; i < errorArray.length; i++) {
        if (errorArray[i] == "" || typeof(errorArray[i]) == "undefined") {
            errorArray.splice(i, 1);
            i = i - 1;
        }
    }
    if (checkCompleteness() == true && errorArray.length == 0) {
        //alert("jump");
        if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var subTotal = $('#orderSubtotal').text();
                var gst = $('#GST').text();
                var totalFee = $('#totalFee').text();
                window.location.href = "checkout2.php?subtotal="+subTotal+"&gst="+gst+"&totalFee="+totalFee;
           }
        };
        xmlhttp.open("GET", "php/shippingInfo.php?firstName="+$("#firstname").val()+"&lastName="+$("#lastname").val()+"&address="+$("#address").val()+"&company="+$("#company").val()+"&country="+$("#country option:selected").text()+"&state="+$("#stateText").val()+"&city="+$("#cityText").val()+"&postcode="+$("#postcode").val()+"&telephone="+$("#phone").val()+"&email="+$("#email").val(),true);
        xmlhttp.send();

    }
}
//check the completeness of the form in checkout1 page
function checkCompleteness(){
    var inputArray = new Array($("#firstname").val(),$("#lastname").val(),$("#address").val(),$("#country option:selected").text(),$("#stateText").val(),$("#cityText").val(),$("#postcode").val(), $("#phone").val(),$("#email").val());
    var count=0;
    for(let i=0; i<inputArray.length; i++) {
        if(inputArray[i] == "") {
            count = count+1;
        }
    }
    if(count==0){
        return true;
    }
    else{
        return false;
    }
}
//pass the parameters in checkout2 form to the session
function finishForms(){
    if($("#cardname").val()==""){
        $("#cardnameError").html("The card name is necessary.");
    }
    else{
        var cardName =  /^([A-Za-z\s]*)$/;
        if(!cardName.test($.trim($("#cardname").val()))){
            $("#cardnameError").html("Card name can only have letters and spaces.");
        }
        else{
            $("#cardnameError").html("");
        }
    }
    if($("#cardnumber").val()==""){
        $("#cardnumberError").html("The card number is necessary.");
    }
    else{
        var cardNumber = /^\d{16}$/;
        if(!cardNumber.test($.trim($("#cardnumber").val()))){
            $("#cardnumberError").html("The card number can only be 16 bits and no space.");
        }
        else{
            $("#cardnumberError").html("");
        }
    }
    if($("#expirymonth").val()==""){
        $("#expirymonthError").html("The Expiry Month (Two digits) is necessary.");
    }
    else{
        var month = /^(0[1-9]|1[0-2])$/;
        if(!month.test($.trim($("#expirymonth").val()))){
            $("#expirymonthError").html("The month can only be 2 bits and no space, from 01 to 12.");
        }
        else{
            $("#expirymonthError").html("");
        }
    }
    if($("#expiryyear").val()=="") {
        $("#expiryyearError").html("The Expiry Year (Two digits) is necessary.");
    }
    else{
        var year = /^\d{2}$/;
        if(!year.test($.trim($("#expiryyear").val()))){
            $("#expiryyearError").html("The year can only be 2 bits and no space, for example: 22");
        }
        else{
            $("#expiryyearError").html("");
        }
    }
    if($("#cvv").val()==""){
        $("#cvvError").html("The CVV (Three digits) is necessary.");
    }
    else{
        var cvv = /^\d{3}$/;
        if(!cvv.test($.trim($("#cvv").val()))){
            $("#cvvError").html("The cvv can only be 3 bits and no space, for example: 927");
        }
        else{
            $("#cvvError").html("");
        }
    }
    var errorArray = new Array($("#cardnameError").text(),$("#cardnumberError").text(),$("#expirymonthError").text(),$("#expiryyearError").text(),$("#cvvError").text());
    for(var i = 0 ;i<errorArray.length;i++)
    {
        if(errorArray[i] == "" || typeof(errorArray[i]) == "undefined")
        {
            errorArray.splice(i,1);
            i= i-1;
        }
    }
    if(checkCardCompleteness()==true&&errorArray.length==0){

        if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                window.location.href = "checkout3.php";
            }
        };
        xmlhttp.open("GET", "php/paymentInfo.php?cardName="+$("#cardname").val()+"&cardNumber="+$("#cardnumber").val()+"&expiryMonth="+$("#expirymonth").val()+"&expiryYear="+$("#expiryyear").val()+"&cvv="+$("#cvv").val(),true);
        xmlhttp.send();
    }
}
//check the completeness of the form in checkout2 page
function checkCardCompleteness(){
    var inputArray = new Array($("#cardname").val(),$("#cardnumber").val(),$("#expirymonth").val(),$("#expiryyear").val(),$("#cvv").val());
    var count=0;
    for(let i=0; i<inputArray.length; i++) {
        if(inputArray[i] == "") {
            count = count+1;
        }
    }
    if(count==0){
        return true;
    }
    else{
        return false;
    }
  }
//modify the shipping info
$('#saveChange').click(function(){
    if ($("#firstname").val() == "") {
        $("#firstnameError").html("The first name is necessary.");
    }
    else{
        var firstname =  /^([A-Za-z\s]*)$/;
        if(!firstname.test($.trim($("#firstname").val()))){
            $("#firstnameError").html("Can only have letters and spaces");
        }
        else{
            $("#firstnameError").html("");
        }
    }
    if ($("#lastname").val() == "") {
        $("#lastnameError").html("The Last name is necessary.");
    }
    else{
        var lastname =  /^([A-Za-z\s]*)$/;
        if(!lastname.test($.trim($("#lastname").val()))){
            $("#lastnameError").html("Can only have letters and spaces");
        }
        else{
            $("#lastnameError").html("");
        }
    }
    if ($("#address").val() == "") {
        $("#addressError").html("The address is necessary.");
    }
    else{
        var address = /^((?:\d+ [a-zA-Z ]{1,5})[a-zA-Z ]+)$/;
        if(!address.test($.trim($("#address").val()))){
            $("#addressError").html("Address must have a house number and a street name, like 55 station street.");
        }
        else{
            $("#addressError").html("");
        }
    }
    if ($("#stateText").val() == "") {
        $("#stateTextError").html("The state is necessary.");
    }
    else{
        var state = /^([A-Za-z\s-]*)$/;
        if(!state.test($.trim($("#stateText").val()))){
            $("#stateTextError").html("Can only have letters, spaces and -");
        }
        else{
            $("#stateTextError").html("");
        }
    }
    if ($("#cityText").val() == "") {
        $("#cityTextError").html("The city is necessary.");
    }
    else{
        var city = /^([A-Za-z\s-]*)$/;
        if(!city.test($.trim($("#cityText").val()))){
            $("#cityTextError").html("Can only have letters, spaces and -");
        }
        else{
            $("#cityTextError").html("");
        }
    }
    if ($("#postcode").val() == "") {
        $("#postcodeError").html("The postcode is necessary.");
    }
    else{
        var postcode = /^(\d{4})$/;
        if(!postcode.test($.trim($("#postcode").val()))){
            $("#postcodeError").html("Postcode can only have 4 digits numbers.");
        }
        else{
            $("#postcodeError").html("");
        }
    }
    if ($("#phone").val() == "") {
        $("#phoneError").html("The telephone is necessary.");
    }
    else{
        var phone = /^(\({0,1}((0|\+61)(2|4|3|7|8)){0,1}\){0,1}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{1}(\ |-){0,1}[0-9]{3})$/;
        if(!phone.test($.trim($("#phone").val()))){
            $("#phoneError").html("Please input the correct phone number.");
        }
        else{
            $("#phoneError").html("");
        }
    }
    if ($("#email").val() == "") {
        $("#emailError").html("The email address is necessary.");
    }
    else{
        var email = /([\w\-]+\@[\w\-]+\.[\w\-]+)/;
        if(!email.test($.trim($("#email").val()))){
            $("#emailError").html("Please input the valid email address");
        }
        else{
            //$("#emailError").html("");
        }
    }
    if ($("#country").val() == "") {
        $("#countryError").html("The country is necessary.");
    }

    var errorArray = new Array($("#firstnameError").text(), $("#lastnameError").text(), $("#addressError").text(), $("#stateTextError").text(), $("#cityTextError").text(), $("#postcodeError").text(), $("#phoneError").text(), $("#countryError").text(), $("#emailError").text());
    for (var i = 0; i < errorArray.length; i++) {
        if (errorArray[i] == "" || typeof(errorArray[i]) == "undefined") {
            errorArray.splice(i, 1);
            i = i - 1;
        }
    }
    if (checkCompleteness() == true && errorArray.length == 0) {
        if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                window.location.href = "php/modifyInfo.php";
            }
        };
        xmlhttp.open("GET", "php/shippingInfo.php?firstName="+$("#firstname").val()+"&lastName="+$("#lastname").val()+"&address="+$("#address").val()+"&company="+$("#company").val()+"&country="+$("#country option:selected").text()+"&state="+$("#stateText").val()+"&city="+$("#cityText").val()+"&postcode="+$("#postcode").val()+"&telephone="+$("#phone").val()+"&email="+$("#email").val(),true);
        xmlhttp.send();
    }

})

function submitContact(){

    if ($("#firstname").val() == "") {
        $("#firstnameError").html("The first name is necessary.");
    }
    else{
        var firstname =  /^([A-Za-z\s]*)$/;
        if(!firstname.test($.trim($("#firstname").val()))){
            $("#firstnameError").html("Can only have letters and spaces");
        }
        else{
            $("#firstnameError").html("");
        }
    }
    if ($("#lastname").val() == "") {
        $("#lastnameError").html("The last name is necessary.");
    }
    else{
        var lastname =  /^([A-Za-z\s]*)$/;
        if(!lastname.test($.trim($("#lastname").val()))){
            $("#lastnameError").html("Can only have letters and spaces");
        }
        else{
            $("#lastnameError").html("");
        }
    }
    if ($("#email").val() == "") {
        $("#emailError").html("The email address is necessary.");
    }
    else{
        var email = /([\w\-]+\@[\w\-]+\.[\w\-]+)/;
        if(!email.test($.trim($("#email").val()))){
            $("#emailError").html("Please input the valid email address");
        }
        else{
            $("#emailError").html("");
        }
    }
    if ($("#message").val() == "") {
        $("#messageError").html("The message is necessary.");
    }
    if ($("#subject").val() == "") {
        $("#subjectError").html("The subject is necessary.");
    }
    if($("#authcode").val() == ""){
        $("#authcodeError").html("The captcha is necessary.");
    }
    var errorArray = new Array($("#firstnameError").text(), $("#lastnameError").text(), $("#emailError").text(),$("#authcodeError").text(),$("#subjectError").text(),$("#messageError").text());
    for (var i = 0; i < errorArray.length; i++) {
        if (errorArray[i] == "" || typeof(errorArray[i]) == "undefined") {
            errorArray.splice(i, 1);
            i = i - 1;
        }
    }
    if (checkCompleteness2() == true && errorArray.length == 0) {
        //alert("jump");
        if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
               if(xmlhttp.responseText=="success"){
                  alert("Message sent successfully!");
                   window.location.href="contact.php";
               }
                else{
                  $("#authcodeError").html("The captcha code is incorrect.");
               }
            }
        };
        xmlhttp.open("GET", "php/checkCaptcha.php?firstName="+$("#firstname").val()+"&lastName="+$("#lastname").val()+"&email="+$("#email").val()+"&authcode="+$('#authcode').val()+"&subject="+$('#subject').val()+"&message="+$('#message').val(),true);
        xmlhttp.send();
    }
}
function checkCompleteness2(){
    var inputArray = new Array($('#authcode').val(),$("#firstname").val(),$("#lastname").val(),$("#email").val(),$('#subject').val(),$('#message').val());
    var count=0;
    for(let i=0; i<inputArray.length; i++) {
        if(inputArray[i] == "") {
            count = count+1;
        }
    }
    if(count==0){
        return true;
    }
    else{
        return false;
    }
}