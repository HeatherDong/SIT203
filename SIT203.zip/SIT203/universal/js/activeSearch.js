//initialize the searching results
var resultsList;
$("#search button").click(function(){
    $(this).get(0).setAttribute("type","button");
    var productResults = resultsList;
    var stringList= new Array();
    stringList=productResults.split('<br>');
    var searchingResult = new Array();
    for(var i=0;i<stringList.length-1;i++){
        searchingResult[i]= stringList[i].substring(stringList[i].indexOf('>')+1,stringList[i].lastIndexOf('<'));
    }
    window.location.href = "searchingResult.php?result="+searchingResult;
});
$("#search input").focus(function(){
    var newNodeBottom = document.createElement("div");
    newNodeBottom.innerHTML = "";
    newNodeBottom.setAttribute("id","searchList");
    this.parentNode.insertBefore(newNodeBottom, this.nextSibling);
});
$('#search').on('input',function () {
    var string=$("#search input").val();
    showResult(string);
});
//showing the search result suggestion.
function showResult(str) {
      if (str.length==0)
      {
        document.getElementById("searchList").innerHTML="";
        document.getElementById("searchList").style.border="0px";
        return;
      }
      if (window.XMLHttpRequest)
      {// IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
      }
      else
      {// IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      xmlhttp.onreadystatechange=function()
      {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
          document.getElementById("searchList").innerHTML=xmlhttp.responseText;
          resultsList = xmlhttp.responseText;
          document.getElementById("searchList").style.border="1px solid #A5ACB2";
          $('.productID').click(function(){
               var productId = $(this).text();
               passingSuggesstion(productId);
          });
        }
      }
      xmlhttp.open("GET","php/activeSearch.php?q="+str,true);
      xmlhttp.send();
    }
//When clicking the suggestion item, pass to the detail page.
function passingSuggesstion(productId){
    var count=0;
    var count1=0;
    $.ajax({
        url: 'furniture_all.xml',
        type: 'GET',
        dataType: 'xml',
        success: function(xml) {
            $(xml).find("FURNITURE").each(function(){
                count=count+1;
            });
            $(xml).find("ACCESSORY").each(function(){
                count1=count1+1;
            });
            $(xml).find("PRODUCT").each(function () {
                var name = $(this).text();
                if(name==productId){
                    var activeClass;
                    var type=this.parentNode.nodeName;
                    var number = count;
                    var number1 = count1;
                    if(type=='BED'||type=='CHAIR'||type=='STORAGE'||type=='TABLE'){
                        type="Furniture"
                    }
                    else{
                        type="Accessory"
                    }
                    window.location.href = "detail.php?id="+productId+"&count="+number+"&count1="+number1+"&type="+type;
                }
            })
        }
    });
}
