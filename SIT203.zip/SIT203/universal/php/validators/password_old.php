<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/15
 * Time: 上午10:39
 */
$password_oldError="";
//validate the old password
if (empty($_GET["password_old"])) {
    $password_oldError = "The new password is necessary.";
} else {
    $password_old = format_data($_GET["password_old"]);
    if (!preg_match("/^[a-zA-Z\d_]{8}$/",$password_old)) {
        $password_oldError = "Your old password should be 8 digits";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $password_oldError;