<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/31
 * Time: 上午10:53
 */
//validate the cvv 
$cvvError="";
if (empty($_GET["cvv"])) {
    $cvvError = "The CVV (Three digits) is necessary.";
} else {
    $cvv = format_data($_GET["cvv"]);
    if (!preg_match("/^\d{3}$/",$cvv)) {
        $cvvError = "The cvv can only be 3 bits and no space, for example: 927";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $cvvError;

