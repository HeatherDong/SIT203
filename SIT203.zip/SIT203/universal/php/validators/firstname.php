<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/21
 * Time: 下午10:44
 */
//validate the first name
$firstnameError="";

if (empty($_GET["firstname"])) {
    $firstnameError = "The first name is necessary.";
} else {
    $firstname = format_data($_GET["firstname"]);
    if (!preg_match("/^[ A-Za-z ]+$/",$firstname)) {
        $firstnameError = "Can only have letters and spaces.";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}

echo $firstnameError;

