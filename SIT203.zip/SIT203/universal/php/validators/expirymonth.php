<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/31
 * Time: 上午10:44
 */
//validate the expiry month
$monthError="";
if (empty($_GET["expirymonth"])) {
    $monthError = "The Expiry Month (Two digits) is necessary.";
} else {
    $month = format_data($_GET["expirymonth"]);
    if (!preg_match("/^0[1-9]|1[0-2]$/",$month)) {
        $monthError = "The month can only be 2 bits and no space, from 01 to 12";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}

echo $monthError;
