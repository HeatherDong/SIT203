<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午3:32
 */
$addressError="";
//validate the street address
if (empty($_GET["address"])) {
    $addressError = "The street address is necessary.";
} else {
    $address = format_data($_GET["address"]);
    if (!preg_match("/^(?:\d+ [a-zA-Z ]{1,5})[a-zA-Z ]+$/",$address)) {
        $addressError = "Address must have a house number and a street name, like 55 station street.";
    }
}
function format_data($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $addressError;