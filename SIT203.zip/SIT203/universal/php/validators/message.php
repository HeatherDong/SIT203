<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/29
 * Time: 下午3:22
 */

$messageError="";
//validate the message.
if (empty($_GET["message"])) {
    $messageError = "The message is necessary.";
}
echo $messageError;