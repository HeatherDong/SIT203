<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/31
 * Time: 上午10:49
 */
//validate the expiry year
$yearError="";
if (empty($_GET["expiryyear"])) {
    $yearError = "The Expiry Year (Two digits) is necessary.";
} else {
    $year = format_data($_GET["expiryyear"]);
    if (!preg_match("/^\d{2}$/",$year)) {
        $yearError = "The year can only be 2 bits and no space, for example: 22";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $yearError;

