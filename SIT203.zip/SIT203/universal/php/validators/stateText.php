<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午3:59
 */
$stateLocationError="";
//validate the location address(state)
if (empty($_GET["stateText"])) {
    $stateLocationError = "The state is necessary.";
} else {
    $stateText = format_data($_GET["stateText"]);
    if (!preg_match("/^[A-Za-z\s-]*$/",$stateText)) {
        $stateLocationError = "Can only have letters, spaces and -.";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $stateLocationError;