<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/14
 * Time: 下午10:18
 */
$password_2Error="";
//validate the repeated new password
if (empty($_GET["password_2"])) {
    $password_2Error = "The repeated password is necessary.";
} else {
    $newPassword2 = format_data($_GET["password_2"]);
    if (!preg_match('/(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[A-Za-z0-9]{8}/', $newPassword2)||strlen($newPassword2)!==8) {
        $password_2Error = "Password must be 8 digits including numbers and letters.";
    }
}

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $password_2Error;