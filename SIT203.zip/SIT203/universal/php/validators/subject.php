<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/29
 * Time: 下午3:22
 */

$subjectError="";
//validate the subject
if (empty($_GET["subject"])) {
    $subjectError = "The subject is necessary.";
}
echo $subjectError;