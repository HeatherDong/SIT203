<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午5:01
 */
$emailError="";
//validate the email address
if (empty($_GET["email"])) {
    $emailError = "The email address is necessary.";
} else {
    $email = format_data($_GET["email"]);
    if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)) {
        $emailError = "Please input the valid email address.";
    }
}

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $emailError;