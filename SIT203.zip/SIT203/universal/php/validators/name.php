<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/16
 * Time: 上午10:16
 */
$nameError="";
//validate the user name
if (empty($_GET["name"])) {
    $nameError = "The username is necessary.";
} else {
    $name = format_data($_GET["name"]);
    if (!preg_match("/^[A-Za-z]{6}$/",$name)) {
        $nameError = "Username should be 6 digits and only has letters";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $nameError;