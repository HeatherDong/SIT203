<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/31
 * Time: 上午10:01
 */
//validate the card name
$cardnameError="";
if (empty($_GET["cardname"])) {
    $cardnameError = "The card name is necessary.";
} else {
    $cardname = format_data($_GET["cardname"]);
    if (!preg_match("/^[A-Za-z ]*$/", $cardname)) {
        $cardnameError = "Card name can only have letters and spaces.";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $cardnameError;

