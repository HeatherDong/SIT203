<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午4:44
 */
$cityLocationError="";
//validate the location address(city)
if (empty($_GET["cityText"])) {
    $cityLocationError = "The city is necessary.";
} else {
    $cityText = format_data($_GET["cityText"]);
    if (!preg_match("/^[A-Za-z\s-]*$/",$cityText)) {
        $cityLocationError = "Can only have letters and spaces and -.";
    }
}

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $cityLocationError;

