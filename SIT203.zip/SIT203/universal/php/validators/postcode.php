<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午4:50
 */
$postcodeError="";

//validate the postcode
if (empty($_GET["postcode"])) {
    $postcodeError = "The postcode is necessary.";
} else {
    $postcode = format_data($_GET["postcode"]);
    if (!preg_match("/^\d{4}$/", $postcode)) {
        $postcodeError = "Postcode can only have 4 digits numbers.";
    }
}

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}

echo $postcodeError;