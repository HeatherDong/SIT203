<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午4:57
 */
$phoneError="";
//validate the phone number
if (empty($_GET["phone"])) {
    $phoneError = "The phone number is necessary.";
} else {
    $phone = format_data($_GET["phone"]);
    if (!preg_match("/^\({0,1}((0|\+61)(2|4|3|7|8)){0,1}\){0,1}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{2}(\ |-){0,1}[0-9]{1}(\ |-){0,1}[0-9]{3}$/", $phone)) {
        $phoneError = "Please input the correct phone number.";
    }
}

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $phoneError;

