<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/31
 * Time: 上午10:14
 */
//validate the card number
$cardnumberError="";
if (empty($_GET["cardnumber"])) {
    $cardnumberError = "The card number is necessary.";
} else {
    $cardnumber = format_data($_GET["cardnumber"]);
    if (!preg_match("/^\d{16}$/",$cardnumber)) {
        $cardnumberError = "The card number can only be 16 bits and no space.";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $cardnumberError;