<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/14
 * Time: 下午10:05
 */
$password_1Error="";
//validate the new password
if (empty($_GET["password_1"])) {
    $password_1Error = "The password is necessary.";
} else {
    $newPassword1 = format_data($_GET["password_1"]);
    if (!preg_match('/(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[A-Za-z0-9]{8}/',$newPassword1)||strlen($newPassword1)!==8) {
        $password_1Error = "Password must be 8 digits including numbers, uppercase and lowercase letters.";
    }
}
function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
echo $password_1Error;