<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午3:22
 */
$lastNameError="";
//validate the last name
if (empty($_GET["lastname"])) {
    $lastNameError = "The last name is necessary.";
} else {
    $lastname = format_data($_GET["lastname"]);
    if (!preg_match("/^[ A-Za-z ]+$/",$lastname)) {
        $lastNameError = "Can only have letters and spaces.";
    }
}

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}

echo $lastNameError;

