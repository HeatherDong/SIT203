<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/30
 * Time: 上午10:14
 */

$authcodeError="";
//validate the street address
if (empty($_GET["authcode"])) {
    $authcodeError = "The captcha is necessary.";
}
echo $authcodeError;