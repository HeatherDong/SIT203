<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/14
 * Time: 下午9:51
 */
//verify the password and username and save new validated password
session_start();
$oldPassword = $_GET['oldPassword'];
$newPassword = $_GET['newPassword1'];
function toHash($salt, $password){
    $string = md5($password.$salt);
    return $string;
}
if(empty($_SESSION['userName'])){
    echo '<script language="javascript"> alert("Please login first!");</script>';
    echo '<script language="javascript"> window.location.href="../register.php"</script>';
}
else{
    require_once ("connect.php");
    $loginName = $_SESSION['userName'];

    $query1="SELECT * FROM Customers where UserName='".$loginName."'";

    $stmt1 = oci_parse($connect, $query1);

    if(!$stmt1)  {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }
    oci_execute($stmt1);

    if(oci_fetch_array($stmt1)) {

        $Password = oci_result($stmt1, "PASSWORD");
        $salt = oci_result($stmt1, "SALT");

        if (!empty($Password)) {
            if ($Password==toHash($salt,$oldPassword)) {
                $newPassword = toHash($salt,$newPassword);
                $sql2="UPDATE Customers SET PASSWORD='".$newPassword."'".
                    "WHERE UserName='".$loginName."'";
                $stmt2= oci_parse($connect, $sql2);
                if(!$stmt2)  {
                    echo "An error occurred in parsing the sql string.\n";
                    exit;
                }
                oci_execute($stmt2);
                echo '<script language="javascript"> alert("Password has been  modified!");</script>';
                echo '<script language="javascript"> window.location.href="../register.php"</script>';
            }
            else {
                echo "<script> alert('Your old password is wrong!') </script>";
                echo '<script language="javascript"> window.location.href="../customer-account.php"</script>';;
            }
        }

    }

    }
