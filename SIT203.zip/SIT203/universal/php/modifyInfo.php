<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/15
 * Time: 下午4:38
 */
//modify the user shipping and payment info
session_start();
require_once ("connect.php");
$firstName = $_SESSION["firstName"];
$lastName = $_SESSION["lastName"];
$address = $_SESSION["address"];
$company = $_SESSION["company"];
$country = $_SESSION["country"];
$state = $_SESSION["state"];
$city = $_SESSION["city"];
$postcode = $_SESSION["postcode"];
$email = $_SESSION["email"];
$telephone = $_SESSION["telephone"];
$cardName = $_SESSION["cardName"];
$cardNumber = $_SESSION["cardNumber"];
$expiryMonth = $_SESSION["expiryMonth"];
$expiryYear = $_SESSION["expiryYear"];
$cvv = $_SESSION["cvv"];

if(!empty($_SESSION["userName"])){
    $userName = $_SESSION["userName"];
    /* build sql statement using form data */
    $_query = "SELECT * FROM Customers WHERE UserName = '" . $userName . "'";

    $_stmt = oci_parse($connect, $_query);

    if (!$_stmt) {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }
    oci_execute($_stmt);
    while (oci_fetch_array($_stmt)) {
        $userId = oci_result($_stmt, 1);
    }

    $sql4="UPDATE Customers SET FirstName='".$firstName."',".
        "LastName='".$lastName."',".
        "Address='".$address."',".
        "Company='".$company."',".
        "City='".$city."',".
        "PostCode='".$postcode."',".
        "State='".$state."',".
        "Country='".$country."',".
        "Telephone='".$telephone."',".
        "Email='".$email."',".
        "NameOnCard='".$cardName."',".
        "CardNumber='".$cardNumber."',".
        "ExpiryMonth='".$expiryMonth."',".
        "ExpiryYear='".$expiryYear."',".
        "CCV='".$cvv."'".
        "WHERE UserName='".$userName."'";

    $stmt4= oci_parse($connect, $sql4);

    if(!$stmt4)  {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }
    oci_execute($stmt4);
}
echo '<script language="javascript">window.location.href="../customer-account.php"</script>';