<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/7
 * Time: 上午10:27
 */
//pass order info the the database
session_start();
require_once ("connect.php");
$email = $_SESSION["email"];
$firstName = $_SESSION["firstName"];
$lastName = $_SESSION["lastName"];
$address = $_SESSION["address"];
$company = $_SESSION["company"];
$country = $_SESSION["country"];
$state = $_SESSION["state"];
$city = $_SESSION["city"];
$postcode = $_SESSION["postcode"];
$telephone = $_SESSION["telephone"];
$cardName = $_SESSION["cardName"];
$cardNumber = $_SESSION["cardNumber"];
$expiryMonth = $_SESSION["expiryMonth"];
$expiryYear = $_SESSION["expiryYear"];
$cvv = $_SESSION["cvv"];


if(!empty($_SESSION["userName"])){
    $userName = $_SESSION["userName"];
    unset($_SESSION['passWord']);
    /* build sql statement using form data */
    $_query = "SELECT * FROM Customers WHERE UserName = '" . $userName . "'";

    /* check the sql statement for errors and if errors report them */
    $_stmt = oci_parse($connect, $_query);

    if (!$_stmt) {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }
    oci_execute($_stmt);
    while (oci_fetch_array($_stmt)) {
        $userId = oci_result($_stmt, 1);
    }

    $sql4="UPDATE Customers SET FirstName='".$firstName."',".
        "LastName='".$lastName."',".
        "Address='".$address."',".
        "Company='".$company."',".
        "City='".$city."',".
        "PostCode='".$postcode."',".
        "State='".$state."',".
        "Country='".$country."',".
        "Telephone='".$telephone."',".
        "Email='".$email."',".
        "NameOnCard='".$cardName."',".
        "CardNumber='".$cardNumber."',".
        "ExpiryMonth='".$expiryMonth."',".
        "ExpiryYear='".$expiryYear."',".
        "CCV='".$cvv."'".
        "WHERE UserName='".$userName."'";

    $stmt4= oci_parse($connect, $sql4);

    if(!$stmt4)  {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }
    oci_execute($stmt4);
}
else{
    $sql1="select Max(UserId) FROM Customers";
    $stmt1 = oci_parse($connect, $sql1);
    if(!$stmt1) {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }
    oci_execute($stmt1);
    if (oci_fetch_array($stmt1)) {
        $currentUserId = oci_result($stmt1,1);
    }
    else {
        echo "An error occurred in retrieving order id.\n";
        exit;
    }
    $userId = $currentUserId+1;
    if(empty($_SESSION['userName'])){
        $password = create_password(8);
    }
    else $password = "";

    $userName = create_username(6);

    $_SESSION['passWord']=$password;

    $_SESSION['userName']=$userName;

    $salt = randomString(8);

    $password = toHash($salt,$password);

    $query = "INSERT INTO Customers (UserId,UserName,PassWord,SALT,FirstName,LastName,Address,Company,Country,State,City,PostCode,Telephone,Email,NameOnCard,CardNumber,ExpiryMonth,ExpiryYear,CCV) VALUES  ($userId,'$userName', '$password','$salt','$firstName', '$lastName', '$address','$company','$country','$state','$city','$postcode','$telephone','$email','$cardName','$cardNumber','$expiryMonth','$expiryYear','$cvv')";

    $stmt = oci_parse($connect, $query);

    if(!$stmt)  {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }

    oci_execute($stmt);
}
$_SESSION['userName']=$userName;
//order list
$query_count = "SELECT max(ID) FROM myOrder";

/* check the sql statement for errors and if errors report them */
$stmt3 = oci_parse($connect, $query_count);

if(!$stmt3)  {
    echo "An error occurred in parsing the sql string.\n";
    exit;
}

oci_execute($stmt3);
if (oci_fetch_array($stmt3))  {

    $currentItemId = oci_result($stmt3,1);//returns the data for column 1

} else {
    echo "An error occurred in retrieving order id.\n";
    exit;
}
$itemId = $currentItemId;
$attr = $_SESSION["cart"];

$sql2="select Max(Order_ID) FROM myOrder";
$stmt2 = oci_parse($connect, $sql2);
if(!$stmt2) {
    echo "An error occurred in parsing the sql string.\n";
    exit;
}
oci_execute($stmt2);
if (oci_fetch_array($stmt2)) {
    $currentOrderId = oci_result($stmt2,1);
}
else {
    echo "An error occurred in retrieving order id.\n";
    exit;
}
$orderId = $currentOrderId+1;
foreach ($attr as $key=>$value)
{
    $itemId++;
    $picture = $value[1];
    $product = $value[2];
    $price = $value[3];
    $quantity = $value[4];
    $subtotal = $value[3]*$value[4];
    $date = date("Y/m/d");
    $query1 = "INSERT INTO myOrder(ID, User_ID, Order_ID, Product, Picture, Time, Price, Quantity, Subtotal, FirstName, LastName, Address, Country, State, City, PostCode) VALUES ($itemId, $userId,'$orderId','$product', '$picture','$date', '$price', '$quantity','$subtotal','$firstName','$lastName','$address','$country','$state','$city','$postcode')";
    /* check the sql statement for errors and if errors report them */
    $stmt2 = oci_parse($connect, $query1);
    if(!$stmt2)  {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }

    oci_execute($stmt2);
}

$attr = $_SESSION["cart"];
unset($attr);
$_SESSION["cart"] = $attr;


echo '<script language="javascript">window.location.href="../checkout4.php"</script>';

//Referenced from : https://www.oschina.net/code/snippet_616695_22223  on 07/09/2018
function create_password($length)
{
    $arr = array_merge(range(0, 9), range('a', 'z'), range('A', 'Z'));
    $str = '';
    $arr_len = count($arr);
    for ($i = 0; $i < $length; $i++)
    {
        $rand = mt_rand(0, $arr_len-1);
        $str.=$arr[$rand];
    }
    return $str;
}
//Referenced from : http://developer.51cto.com/art/201702/530078.htm   on 07/09/2018
function create_username( $length = 6 )  {
    $str = substr(md5(time()), 0, 6);
    return $str;
}

function randomString($length = 8){
    $str = substr(md5(time()), 0, 8);
    return $str;
}
//add the random string to the password
function toHash($salt, $password){
    $string = md5($password.$salt);
    return $string;
}
oci_close($connect);
?>