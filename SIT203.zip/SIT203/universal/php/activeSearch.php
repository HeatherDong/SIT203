<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/1
 * Time: 下午1:44
 */
//active search from product name
//Referenced from :  https://www.jb51.net/article/136320.htm
$xml = new DOMDocument();
$product=array();
$xml->load("../furniture_all.xml");
$targets = $xml->getElementsByTagName("PRODUCT");
foreach($targets as $target){
        $product[]=$target->nodeValue;
}
$tmp=$_GET['q'];
$val=array();
$k=0;

if (strlen($tmp)>0)
{
    for($i=0;$i<20;$i++){
        if(stripos($product[$i],$tmp)!==false){
            $val[$k]=$product[$i];
            $k=$k+1;
        }
    }
    for($j=0;$j<count($val);$j++)
    {
        echo "<a class='productID' style='text-decoration: none; cursor:pointer;'>$val[$j]</a>";
        echo "<br>";
    }
}
