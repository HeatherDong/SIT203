<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/27
 * Time: 上午11:23
 */
session_start();
require_once ('connect.php');
header("Content-Type:text/html;charset=utf-8");
function format_data($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
if(isset($_GET['authcode'])){
    if(strtolower(format_data($_GET['authcode']))== $_SESSION['authcode']){
        $firstname = format_data($_GET['firstname']);
        $lastname = format_data($_GET['lastname']);
        $email = format_data($_GET['email']);
        $subject =  format_data($_GET['subject']);
        $message = format_data($_GET['message']);

        $sql1="select Max(ID) FROM contact";
        $stmt1 = oci_parse($connect, $sql1);
        if(!$stmt1) {
            echo "An error occurred in parsing the sql string.\n";
            exit;
        }
        oci_execute($stmt1);
        if (oci_fetch_array($stmt1)) {
            $currentId = oci_result($stmt1,1);
        }
        else {
            echo "An error occurred in retrieving order id.\n";
            exit;
        }
        $Id = $currentId+1;

        $query = "INSERT INTO contact (ID,FirstName,LastName,Email,Subject,Message) VALUES ($Id,'$firstname', '$lastname','$email','$subject', '$message')";

        $stmt = oci_parse($connect, $query);

        if(!$stmt)  {
            echo "An error occurred in parsing the sql string.\n";
            exit;
        }
        oci_execute($stmt);
        echo "success";
    }

    }
    else{
       echo "fail";
    }
   /* exit();*/
