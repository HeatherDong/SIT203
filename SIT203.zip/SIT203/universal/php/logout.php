<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/13
 * Time: 上午11:16
 */
//logout
session_start();
unset($_SESSION["cart"]);
$_SESSION['userName'] = null;
$_SESSION["email"] = null;
$_SESSION["firstName"] = null;
$_SESSION["lastName"] = null;
$_SESSION["address"]= null;
$_SESSION["company"] = null;
$_SESSION["country"] = null;
$_SESSION["state"]= null;
$_SESSION["city"]=null;
$_SESSION["postcode"]=null;
$_SESSION["telephone"]=null;
$_SESSION["cardName"]=null;
$_SESSION["cardNumber"]=null;
$_SESSION["expiryMonth"]=null;
$_SESSION["expiryYear"]=null;
$_SESSION["cvv"]=null;
echo '<script language="javascript"> window.location.href="../index.php"</script>';