<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/14
 * Time: 下午4:03
 */

//register a new account
session_start();
unset($_SESSION["cart"]);
$_SESSION["userName"] = null;
$_SESSION["email"] = null;
$_SESSION["firstName"] = null;
$_SESSION["lastName"] = null;
$_SESSION["address"]= null;
$_SESSION["company"] = null;
$_SESSION["country"] = null;
$_SESSION["state"]= null;
$_SESSION["city"]=null;
$_SESSION["postcode"]=null;
$_SESSION["telephone"]=null;
$_SESSION["cardName"]=null;
$_SESSION["cardNumber"]=null;
$_SESSION["expiryMonth"]=null;
$_SESSION["expiryYear"]=null;
$_SESSION["cvv"]=null;
$userName = $_GET["userName"];
$email = $_GET["email"];
$passWord = $_GET["passWord"];
$userName=trim($userName," ");
$email=trim($email," ");
$passWord=trim($passWord," ");
$salt = randomString(8);
$passWord = toHash($salt,$passWord);
require_once ('connect.php');
$sql1="select Max(UserId)FROM Customers";
$stmt1 = oci_parse($connect, $sql1);
if(!$stmt1) {
    echo "An error occurred in parsing the sql string.\n";
    exit;
}
oci_execute($stmt1);
if (oci_fetch_array($stmt1))  {
    $currentUserId = oci_result($stmt1,1);
}
$UserId=$currentUserId+1;

$sql2="select * FROM Customers where Email='".$email."'";
$stmt2 = oci_parse($connect, $sql2);
if(!$stmt2) {
    echo "An error occurred in parsing the sql string.\n";
    exit;
}
oci_execute($stmt2);

if (!oci_fetch_array($stmt2))  {
    $sql3="INSERT INTO Customers
		(UserId,UserName,PassWord,Email,Salt) VALUES 
		(:UserId,:UserName,:PassWord,:Email,:Salt)";
    $stmt3 = oci_parse($connect, $sql3);
    if(!$stmt3) {
        echo "An error occurred in parsing the sql string.\n";
        exit;
    }
    oci_bind_by_name($stmt3,":UserId",$UserId);
    oci_bind_by_name($stmt3,":UserName",$userName);
    oci_bind_by_name($stmt3,":PassWord",$passWord);
    oci_bind_by_name($stmt3,":Email",$email);
    oci_bind_by_name($stmt3,":Salt",$salt);
    oci_execute($stmt3);
    $_SESSION['userName']=$userName;
    echo '<script language="javascript"> window.location.href="../customer-account.php"</script>';
}
else
    {
    echo '<script language="javascript"> alert("The Email is exist! Please change another one");</script>';
    unset($_SESSION['userName']);
    unset($_SESSION['email']);
    echo '<script language="javascript"> window.location.href="../register.php"</script>';
}

function randomString($length = 8){
    $str = substr(md5(time()), 0, 8);
    return $str;
}
//add the random string to the password
function toHash($salt, $password){
    $string = md5($password.$salt);
    return $string;
}

