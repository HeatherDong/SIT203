<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/7
 * Time: 下午8:56
 */
//save payment info to session
session_start();
$cardName=format_data($_GET['cardName']);
$cardNumber=format_data($_GET['cardNumber']);
$expiryMonth=format_data($_GET['expiryMonth']);
$expiryYear=format_data($_GET['expiryYear']);
$cvv=format_data($_GET['cvv']);

$_SESSION["cardName"]=$cardName;
$_SESSION["cardNumber"]=$cardNumber;
$_SESSION["expiryMonth"]=$expiryMonth;
$_SESSION["expiryYear"]=$expiryYear;
$_SESSION["cvv"]=$cvv;

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}