<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/8/30
 * Time: 下午8:50
 */
//save shipping info to session
session_start();
$firstName=format_data($_GET['firstName']);
$lastName=format_data($_GET['lastName']);
$address=format_data($_GET['address']);
$company=format_data($_GET['company']);
$country=format_data($_GET['country']);
$state=format_data($_GET['state']);
$city=format_data($_GET['city']);
$postcode=format_data($_GET['postcode']);
$telephone=format_data($_GET['telephone']);
$email=format_data($_GET['email']);


$_SESSION["firstName"]=$firstName;
$_SESSION["lastName"]=$lastName;
$_SESSION["address"]=$address;
$_SESSION["company"]=$company;
$_SESSION["country"]=$country;
$_SESSION["state"]=$state;
$_SESSION["city"]=$city;
$_SESSION["postcode"]=$postcode;
$_SESSION["telephone"]=$telephone;
$_SESSION["email"]=$email;

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}