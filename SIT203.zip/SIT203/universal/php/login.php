<?php
/**
 * Created by PhpStorm.
 * User: dongnan
 * Date: 2018/9/13
 * Time: 上午9:05
 */
//verify login
session_start();
unset($_SESSION["cart"]);
$_SESSION['userName'] = null;
$_SESSION["email"] = null;
$_SESSION["firstName"] = null;
$_SESSION["lastName"] = null;
$_SESSION["address"]= null;
$_SESSION["company"] = null;
$_SESSION["country"] = null;
$_SESSION["state"]= null;
$_SESSION["city"]=null;
$_SESSION["postcode"]=null;
$_SESSION["telephone"]=null;
$_SESSION["cardName"]=null;
$_SESSION["cardNumber"]=null;
$_SESSION["expiryMonth"]=null;
$_SESSION["expiryYear"]=null;
$_SESSION["cvv"]=null;

$loginName = format_data($_GET["loginName"]);

$loginPwd = format_data($_GET["loginPwd"]);

function format_data($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data,ENT_QUOTES,'UTF-8');
    return $data;
}
function toHash($salt, $password){
    $string = md5($password.$salt);
    return $string;
}
require_once ("connect.php");
$query1="SELECT * FROM Customers where Email='".$loginName."'";
$stmt1 = oci_parse($connect, $query1);
if(!$stmt1)  {
    echo "An error occurred in parsing the sql string.\n";
    exit;
}
oci_execute($stmt1);
if(oci_fetch_array($stmt1)) {
    $salt= oci_result($stmt1,"SALT");
    $password= oci_result($stmt1,"PASSWORD");
    if(toHash($salt,$loginPwd)==$password){
        $userName= oci_result($stmt1,"USERNAME");
        $_SESSION['userName']=$userName;
        echo '<script language="javascript"> window.location.href="../customer-orders.php"</script>';
    }
    else{
        echo "<script> alert('Email and Password is incorrect!') </script>";
        echo '<script language="javascript"> window.location.href="../register.php"</script>';
    }
}
else{
    echo "<script> alert('Please register firstly!') </script>";
    echo '<script language="javascript"> window.location.href="../register.php"</script>';
}