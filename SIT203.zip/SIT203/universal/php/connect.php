<?php
/* Set oracle user login and password info */
$dbuser = "hdong";  /* your deakin login */
$dbpass = "218988DNdn";  /* your deakin password */
$dbname = "SSID";
$connect = oci_connect($dbuser, $dbpass, $dbname);

if (!$connect)  {
    echo "An error occurred connecting to the database";
    exit;
}

?>